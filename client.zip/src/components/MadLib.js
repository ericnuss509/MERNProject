import React from 'react'

const MadLib = () => {
    return (
        <div>
            <h1>this is where the user will do the random word swap</h1>
        </div>
    )
}

export default MadLib
